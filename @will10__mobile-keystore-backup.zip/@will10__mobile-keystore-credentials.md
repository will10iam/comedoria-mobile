# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: 69b9a68fd4284ffb908d2039c107cca3
- Android key alias: QHdpbGwxMC9tb2JpbGU=
- Android key password: 5a291e6c2df544c7b01594c8998ae44a
      